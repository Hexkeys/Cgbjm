"""RemotePad agent.

Runs on the PC you want to control. It makes an OUTBOUND connection to your
RemotePad server (no port forwarding needed), streams the screen as JPEG
frames, and performs the mouse/keyboard input sent from the web app.

The agent only streams while a browser is actually watching. It runs in a
visible console window; close the window to stop it.
"""
import argparse
import io
import json
import os
import socket
import sys
import threading
import time
import uuid
import zlib
from pathlib import Path
from urllib.parse import quote

try:
    import ctypes
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        ctypes.windll.user32.SetProcessDPIAware()
except Exception:
    pass

import mss
import websocket
from PIL import Image, ImageDraw
from pynput.keyboard import Controller as KeyboardController, Key
from pynput.mouse import Button, Controller as MouseController

APP_DIR = Path(os.environ.get("APPDATA", Path.home())) / "RemotePad"
CONFIG_FILE = APP_DIR / "config.json"

PRESETS = {
    "low": {"scale": 0.5, "q": 45, "fps": 6},
    "med": {"scale": 0.75, "q": 60, "fps": 8},
    "high": {"scale": 1.0, "q": 72, "fps": 10},
}

SPECIAL = {
    "enter": Key.enter, "backspace": Key.backspace, "tab": Key.tab, "esc": Key.esc,
    "space": Key.space, "del": Key.delete, "ins": Key.insert, "home": Key.home,
    "end": Key.end, "pgup": Key.page_up, "pgdn": Key.page_down, "up": Key.up,
    "down": Key.down, "left": Key.left, "right": Key.right, "caps": Key.caps_lock,
    "prtsc": Key.print_screen, "win": Key.cmd, "ctrl": Key.ctrl, "alt": Key.alt,
    "shift": Key.shift,
}
for _i in range(1, 13):
    SPECIAL[f"f{_i}"] = getattr(Key, f"f{_i}")
MODS = {"ctrl": Key.ctrl, "alt": Key.alt, "shift": Key.shift, "win": Key.cmd}
BUTTONS = {"left": Button.left, "right": Button.right, "middle": Button.middle}


def log(*a):
    print(time.strftime("[%H:%M:%S]"), *a, flush=True)


def num(v, lo, hi, default=0.0):
    try:
        return max(lo, min(hi, float(v)))
    except (TypeError, ValueError):
        return default


def load_config(args):
    cfg = {}
    if CONFIG_FILE.exists():
        try:
            cfg = json.loads(CONFIG_FILE.read_text("utf-8"))
        except Exception:
            cfg = {}
    cfg["server"] = args.server or os.environ.get("REMOTEPAD_SERVER") or cfg.get("server", "")
    cfg["token"] = args.token or os.environ.get("REMOTEPAD_TOKEN") or cfg.get("token", "")
    if not cfg["server"]:
        cfg["server"] = input("Server URL (e.g. https://remotepad.onrender.com): ").strip()
    if not cfg["token"]:
        cfg["token"] = input("Agent token: ").strip()
    cfg.setdefault("device_id", uuid.uuid4().hex[:12])
    cfg["name"] = args.name or cfg.get("name") or socket.gethostname()
    try:
        APP_DIR.mkdir(parents=True, exist_ok=True)
        CONFIG_FILE.write_text(json.dumps(cfg, indent=2), "utf-8")
    except Exception as e:
        log("Could not save config:", e)
    return cfg


def ws_url(server, cfg):
    s = server.strip().rstrip("/")
    if "://" not in s:
        s = "https://" + s
    s = s.replace("https://", "wss://", 1).replace("http://", "ws://", 1)
    return f"{s}/agent?id={quote(cfg['device_id'])}&name={quote(cfg['name'])}"


class Agent:
    def __init__(self, cfg):
        self.cfg = cfg
        self.url = ws_url(cfg["server"], cfg)
        self.ws = None
        self.viewers = 0
        self.force = True
        self.preset = PRESETS["med"]
        self.mouse = MouseController()
        self.kb = KeyboardController()
        self._mon = None
        self._mon_t = 0.0

    # ---------- connection ----------
    def run(self):
        delay = 2
        while True:
            started = time.time()
            self.ws = websocket.WebSocketApp(
                self.url,
                header=[f"Authorization: Bearer {self.cfg['token']}"],
                on_open=self.on_open,
                on_message=self.on_message,
                on_close=self.on_close,
                on_error=lambda ws, e: log("connection error:", e),
            )
            try:
                self.ws.run_forever(ping_interval=25, ping_timeout=10)
            except Exception as e:
                log("connection failed:", e)
            self.viewers = 0
            delay = 2 if time.time() - started > 30 else min(delay * 2, 60)
            log(f"Disconnected. Reconnecting in {delay}s...")
            time.sleep(delay)

    def on_open(self, ws):
        log("Connected to server as", self.cfg["name"])
        mon = self.monitor()
        ws.send(json.dumps({"type": "hello", "w": mon["width"], "h": mon["height"]}))
        threading.Thread(target=self.stream, args=(ws,), daemon=True).start()

    def on_close(self, ws, code, msg):
        log("Connection closed", code or "")

    # ---------- screen ----------
    def monitor(self):
        if self._mon is None or time.time() - self._mon_t > 5:
            with mss.mss() as s:
                self._mon = dict(s.monitors[1])
            self._mon_t = time.time()
        return self._mon

    def stream(self, ws):
        last_key, last_sent = None, 0.0
        with mss.mss() as sct:
            while self.ws is ws and ws.keep_running:
                if self.viewers <= 0:
                    last_key = None
                    time.sleep(0.2)
                    continue
                t0 = time.time()
                p = self.preset
                try:
                    mon = sct.monitors[1]
                    shot = sct.grab(mon)
                    img = Image.frombytes("RGB", shot.size, shot.bgra, "raw", "BGRX")
                    scale = min(p["scale"], 1920 / max(1, mon["width"]))
                    if scale < 1:
                        img = img.resize((max(1, int(img.width * scale)), max(1, int(img.height * scale))), Image.BILINEAR)
                    mx, my = self.mouse.position
                    key = (zlib.crc32(img.tobytes()), mx, my, p["q"])
                    if self.force:
                        self.force, last_key = False, None
                    if key == last_key and t0 - last_sent < 3:
                        time.sleep(0.05)
                        continue
                    last_key, last_sent = key, t0

                    f = max(1.0, img.width / 900)
                    cx, cy = (mx - mon["left"]) * scale, (my - mon["top"]) * scale
                    pts = [(0, 0), (0, 16), (4, 12), (8, 19), (10, 18), (6, 11), (12, 11)]
                    ImageDraw.Draw(img).polygon([(cx + x * f, cy + y * f) for x, y in pts], fill="white", outline="black")

                    buf = io.BytesIO()
                    img.save(buf, "JPEG", quality=p["q"])
                    ws.send(buf.getvalue(), opcode=websocket.ABNF.OPCODE_BINARY)
                except Exception as e:
                    log("stream error:", e)
                    time.sleep(0.5)
                    if not ws.keep_running:
                        break
                    continue
                time.sleep(max(0.0, 1.0 / p["fps"] - (time.time() - t0)))

    # ---------- input ----------
    def on_message(self, ws, message):
        if isinstance(message, (bytes, bytearray)):
            return
        try:
            self.handle(json.loads(message))
        except Exception as e:
            log("bad message:", e)

    def handle(self, m):
        t = m.get("type")
        if t == "viewers":
            n = int(num(m.get("count"), 0, 1000))
            if n > self.viewers:
                self.force = True
            if n != self.viewers:
                log("Viewers watching:", n)
            self.viewers = n
        elif t == "quality":
            self.preset = PRESETS.get(m.get("preset"), self.preset)
            self.force = True
        elif t == "move":
            self.mouse.move(int(num(m.get("dx"), -2000, 2000)), int(num(m.get("dy"), -2000, 2000)))
        elif t == "abs":
            mon = self.monitor()
            x = mon["left"] + int(num(m.get("x"), 0, 1) * (mon["width"] - 1))
            y = mon["top"] + int(num(m.get("y"), 0, 1) * (mon["height"] - 1))
            self.mouse.position = (x, y)
        elif t == "click":
            self.mouse.click(BUTTONS.get(m.get("button"), Button.left), int(num(m.get("count", 1), 1, 3, 1)))
        elif t == "down":
            self.mouse.press(BUTTONS.get(m.get("button"), Button.left))
        elif t == "up":
            self.mouse.release(BUTTONS.get(m.get("button"), Button.left))
        elif t == "scroll":
            # viewer: positive = scroll down; pynput: positive = scroll up
            self.mouse.scroll(0, -int(num(m.get("dy"), -50, 50)))
        elif t == "text":
            self.kb.type(str(m.get("text", ""))[:200])
        elif t == "key":
            self.press_key(str(m.get("key", "")), m.get("mods") or [])

    def press_key(self, name, mods):
        key = SPECIAL.get(name) or (name if len(name) == 1 else None)
        if key is None:
            return
        held = []
        for mod in mods:
            k = MODS.get(mod)
            if k is not None and k not in held:
                held.append(k)
        for k in held:
            self.kb.press(k)
        try:
            self.kb.press(key)
            self.kb.release(key)
        finally:
            for k in reversed(held):
                self.kb.release(k)


def main():
    ap = argparse.ArgumentParser(description="RemotePad agent")
    ap.add_argument("--server", help="Server URL, e.g. https://remotepad.onrender.com")
    ap.add_argument("--token", help="Agent token (AGENT_TOKEN on the server)")
    ap.add_argument("--name", help="Display name for this PC")
    args = ap.parse_args()

    print("=" * 60)
    print(" RemotePad agent")
    print(" This PC can be viewed and controlled from your RemotePad")
    print(" server while this window is open. Close it to stop.")
    print("=" * 60)

    cfg = load_config(args)
    log("Config:", CONFIG_FILE)
    try:
        Agent(cfg).run()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
